import { Component, EventEmitter, Input, Output } from '@angular/core';
import {FilterData} from './filterData';
@Component({
  selector: 'app-root',
	template: `
	<input type="text" [(ngModel)]="myNums">
	<ul>
		<li *ngFor="let point of (points | filterData: myNums)">
			{{point}}
		</li>
	</ul>`
})
export class AppComponent {
	myNums:any = "";

	points: string[] = [
		 'aa',
		 'bb',
		 'cc',
		 'dd' 
	];
}